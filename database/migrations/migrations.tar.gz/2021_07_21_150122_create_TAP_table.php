<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTAPTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('TAP', function (Blueprint $table) {
            $table->integer('id', true);
            $table->smallInteger('class_id')->index('class_id');
            $table->string('name');
            $table->integer('num_proteins')->nullable();
            $table->string('special_rule')->nullable();
            $table->text('alignment')->nullable();
            $table->text('tree')->nullable();
            $table->text('method')->nullable();
            $table->text('no_tree')->nullable();
            $table->integer('num_prot_alignment')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('TAP');
    }
}
