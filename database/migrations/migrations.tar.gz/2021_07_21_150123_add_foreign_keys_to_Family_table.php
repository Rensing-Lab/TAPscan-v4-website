<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToFamilyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('Family', function (Blueprint $table) {
            $table->foreign('order_id', 'Family_ibfk_1')->references('id')->on('Order')->onUpdate('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('Family', function (Blueprint $table) {
            $table->dropForeign('Family_ibfk_1');
        });
    }
}
