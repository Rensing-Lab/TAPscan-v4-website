<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIsoformPositionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('IsoformPositions', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('isoform_id')->index('isoform_id');
            $table->integer('domain_id')->index('domain_id');
            $table->integer('start');
            $table->integer('end');
            # $table->primary(['id', 'isoform_id', 'domain_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('IsoformPositions');
    }
}
