<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToProteinPositionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ProteinPositions', function (Blueprint $table) {
            $table->foreign('protein_id', 'ProteinPositions_ibfk_1')->references('id')->on('Protein')->onUpdate('CASCADE');
            $table->foreign('domain_id', 'ProteinPositions_ibfk_2')->references('id')->on('Domain')->onUpdate('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ProteinPositions', function (Blueprint $table) {
            $table->dropForeign('ProteinPositions_ibfk_1');
            $table->dropForeign('ProteinPositions_ibfk_2');
        });
    }
}
