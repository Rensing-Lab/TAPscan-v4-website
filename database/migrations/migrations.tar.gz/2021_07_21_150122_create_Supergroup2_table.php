<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSupergroup2Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Supergroup2', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('clade_id')->index('clade_id');
            $table->string('name');
            $table->integer('order_number')->unique('order_number');
            $table->integer('num_species')->nullable();
            $table->integer('num_species_all')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Supergroup2');
    }
}
