<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCladeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Clade', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('kingdom_id')->index('kingdom_id');
            $table->string('name');
            $table->integer('order_number')->unique('order_number');
            $table->integer('num_species')->nullable();
            $table->integer('num_species_all')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Clade');
    }
}
