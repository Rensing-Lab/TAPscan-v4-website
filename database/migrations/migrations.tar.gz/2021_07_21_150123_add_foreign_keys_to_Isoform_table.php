<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToIsoformTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('Isoform', function (Blueprint $table) {
            $table->foreign('species_id', 'Isoform_ibfk_1')->references('species_id')->on('Occurrence')->onUpdate('CASCADE');
            $table->foreign('tap_id', 'Isoform_ibfk_2')->references('tap_id')->on('Occurrence')->onUpdate('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('Isoform', function (Blueprint $table) {
            $table->dropForeign('Isoform_ibfk_1');
            $table->dropForeign('Isoform_ibfk_2');
        });
    }
}
