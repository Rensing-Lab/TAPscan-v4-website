<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIsoformTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Isoform', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('species_id')->index('species_id');
            $table->integer('tap_id')->index('tap_id');
            $table->string('name');
            $table->text('alt')->nullable();
            $table->text('sequence');
            # $table->primary(['id', 'species_id', 'tap_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Isoform');
    }
}
