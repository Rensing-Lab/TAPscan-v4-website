<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProteinPositionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ProteinPositions', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('protein_id')->index('protein_id');
            $table->integer('domain_id')->index('domain_id');
            $table->integer('start');
            $table->integer('end');
            # $table->primary(['id', 'protein_id', 'domain_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ProteinPositions');
    }
}
