<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToContainTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('Contain', function (Blueprint $table) {
            $table->foreign('tap_id', 'Contain_ibfk_1')->references('id')->on('TAP')->onUpdate('CASCADE');
            $table->foreign('domain_id', 'Contain_ibfk_2')->references('id')->on('Domain')->onUpdate('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('Contain', function (Blueprint $table) {
            $table->dropForeign('Contain_ibfk_1');
            $table->dropForeign('Contain_ibfk_2');
        });
    }
}
