<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToSupergroup2Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('Supergroup2', function (Blueprint $table) {
            $table->foreign('clade_id', 'Supergroup2_ibfk_1')->references('id')->on('Clade')->onUpdate('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('Supergroup2', function (Blueprint $table) {
            $table->dropForeign('Supergroup2_ibfk_1');
        });
    }
}
