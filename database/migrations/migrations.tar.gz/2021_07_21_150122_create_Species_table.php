<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpeciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Species', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('family_id')->index('clade_id');
            $table->string('name');
            $table->integer('order_number')->unique('order_number');
            $table->string('lettercode');
            $table->string('dataset');
            $table->integer('taxid')->nullable();
            $table->tinyInteger('published')->default(1);
            $table->string('protein_source')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Species');
    }
}
